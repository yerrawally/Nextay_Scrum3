﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Home_Rental.Models;
using System.Data.SqlClient;
using System.Data;

namespace Home_Rental.Controllers
{
    public class DefaultController : Controller
    {
        // GET: Default
        public string value = "";
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(Class1 e)
        {
            if (Request.HttpMethod == "POST")
            {
                Class1 er = new Class1();
                using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Project-NexTay; Integrated Security = True"))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_EnrollDetail", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@UserName", e.FirstName);
                        cmd.Parameters.AddWithValue("@UserPassword", e.Password);
                        cmd.Parameters.AddWithValue("@Gender", e.Gender);
                        cmd.Parameters.AddWithValue("@UserEmail", e.Email);
                        cmd.Parameters.AddWithValue("@MobileNumber", e.PhoneNumber);
                        cmd.Parameters.AddWithValue("@status", "Insert");
                        con.Open();
                        ViewData["result"] = cmd.ExecuteNonQuery();
                        con.Close();
                        return RedirectToAction("Login", "UserLogin");

                    }
                }
            }
            return View();
        }
    }
}