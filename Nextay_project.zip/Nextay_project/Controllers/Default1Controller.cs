﻿
using System.Data.SqlClient;
using System.Configuration;


using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Home_Rental.Models;
namespace Home_Rental.Controllers
{
    public class UserLoginController : Controller
    {
        // GET: UserLogin
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(Enrollment objUser)
        {
            if (ModelState.IsValid)
            {
                using ( Entities db = new Entities ())
                {
                    var obj = db.Enrollments.Where(a => a.UserEmail.Equals(objUser.UserEmail) && a.UserPassword.Equals(objUser.UserPassword)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["ID"] = obj.ID.ToString();
                        Session["Email"] = obj.UserEmail.ToString();
                        return Redirect("http://localhost:55715/Models/Index1.html");
                    }
                }
            }
            return View(objUser);
        }
        public ActionResult UserDashBoard()
        {
            if (Session["ID"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index.html");
            }
        }
    }
}

