﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Home_Rental.Models;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;

namespace Home_Rental.Controllers
{
    public class FeedsController : Controller
    {
        // GET: Feeds
        public string value = "";



        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(Feedback e)
        {
            if (Request.HttpMethod == "POST")
            {
                Feedback er = new Feedback();
                using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Project-NexTay; Integrated Security = True"))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_EnrollFeedback", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@UserId", e.ID);
                        cmd.Parameters.AddWithValue("@Rating", e.Rating);
                        cmd.Parameters.AddWithValue("@feedback", e.feedback);
                        cmd.Parameters.AddWithValue("@Email", e.email);
                        cmd.Parameters.AddWithValue("@status", "INSERT");
                        con.Open();
                        ViewData["result"] = cmd.ExecuteNonQuery();
                        con.Close();
                        return Redirect("http://localhost:55715/Models/thanksfeed.html");
                    }
                }
            }
            return View();
        }

    }
}