﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Home_Rental.Models
{
    public class Feedback
    {
            [Display(Name = "UserID")]
            public int ID { get; set; }



            [Required(ErrorMessage = "Please give the Rating...!")]
            [Display(Name = "Choose the Rating...")]
            public string Rating { get; set; }



            [Required(ErrorMessage = "Please give feedback...!")]
            [Display(Name = "Feedback")]
            public string feedback { get; set; }



            [Required(ErrorMessage = "Please provid your Email...!")]
            [Display(Name = "Email")]
            public string email { get; set; }



            public List<Feedback> Feedbacksinfo { get; set; }
        
    }
}